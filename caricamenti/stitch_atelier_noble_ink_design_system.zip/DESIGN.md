---
name: Haute Joaillerie Ink
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1c1c'
  surface-container: '#1f2020'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e4e2e1'
  on-surface-variant: '#d1c5af'
  inverse-surface: '#e4e2e1'
  inverse-on-surface: '#303030'
  outline: '#9a907b'
  outline-variant: '#4e4635'
  surface-tint: '#eec148'
  primary: '#f8ca50'
  on-primary: '#3e2e00'
  primary-container: '#daaf37'
  on-primary-container: '#594300'
  inverse-primary: '#765b00'
  secondary: '#c6c6c6'
  on-secondary: '#303030'
  secondary-container: '#474747'
  on-secondary-container: '#b5b5b5'
  tertiary: '#ffc758'
  on-tertiary: '#412d00'
  tertiary-container: '#e2ab37'
  on-tertiary-container: '#5d4100'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdf94'
  primary-fixed-dim: '#eec148'
  on-primary-fixed: '#251a00'
  on-primary-fixed-variant: '#594400'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c6'
  on-secondary-fixed: '#1b1b1b'
  on-secondary-fixed-variant: '#474747'
  tertiary-fixed: '#ffdea6'
  tertiary-fixed-dim: '#f7bd48'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5d4200'
  background: '#131313'
  on-background: '#e4e2e1'
  surface-variant: '#353535'
typography:
  display-2xl:
    fontFamily: EB Garamond
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: 0.25em
  display-2xl-mobile:
    fontFamily: EB Garamond
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
    letterSpacing: 0.2em
  display-xl:
    fontFamily: EB Garamond
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: 0.25em
  headline-lg:
    fontFamily: EB Garamond
    fontSize: 30px
    fontWeight: '400'
    lineHeight: 38px
    letterSpacing: 0.15em
  headline-md:
    fontFamily: EB Garamond
    fontSize: 24px
    fontWeight: '400'
    lineHeight: 32px
    letterSpacing: 0.08em
  headline-sm:
    fontFamily: EB Garamond
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0.05em
  body-lg:
    fontFamily: EB Garamond
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0.02em
  body-base:
    fontFamily: EB Garamond
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0.01em
  body-italic:
    fontFamily: EB Garamond
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 32px
    letterSpacing: 0.02em
  label-substudio:
    fontFamily: EB Garamond
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.4em
  label-eyebrow:
    fontFamily: EB Garamond
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.25em
  label-micro:
    fontFamily: EB Garamond
    fontSize: 10px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.3em
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 1.5rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

### Visual Personality & Ethos
The design system manifests an intimate, neoclassical salon atmosphere where dermatological permanence merges with classical fine art and haute horlogerie precision. Transcending conventional tattoo tropes, it adopts an aristocratic Italian salon aesthetic: uncompromising restraint, architectural symmetry, whisper-quiet luxury, and reverence for patient craftsmanship. 

The aesthetic is characterized by:
- **Atmospheric Duality:** A rhythmic transition between luminous, warm alabaster parchment and pitch obsidian inkwells.
- **Sculptural Minimalism:** Generous negative space acting as high-grade gallery matting, allowing artwork and typography to breathe.
- **Precious Metal Accents:** Antique imperial gold leaf and burnished bronze accents that illuminate critical hierarchy points like gilded manuscripts.
- **Classical Balance:** Symmetrical, axial layouts grounded by delicate diamond lozenges and hairline borders.

### Emotional Response
The interface must evoke veneration, clinical hygiene blended with sacred ritual, supreme discretion, and museum-grade prestige. Every interaction should feel intentional, frictionless, and dignified.

## Colors

### Primary Architecture
The palette is structured to support both nocturnal deep-ink chambers and sunlit marble salons, treating black not as an empty space, but as pure carbon pigment.

- **Atelier Imperial Gold (`#DAAF37` / Primary):** The core metallic accent. Reserved for active states, brand emblems, jewel dividers, and metadata eyebrows.
- **Noir Ink Absolute (`#000000` / Secondary):** Deepest carbon black. Forms primary surfaces, high-contrast dark rooms, and crisp outline structures.
- **Burnished Bronze (`#B8860B` / Tertiary):** Grounded antiqued metallic used for rich gradient transitions, pressed states, and low-key accents.
- **Ink Charcoal (`#262626` / Neutral):** Neutral foundation preventing harsh visual contrast on lighter paper surfaces; used for primary body copy in illuminated states.

### Secondary & Surface Hierarchy
- **Noir Deep (`#0A0A0A`):** Tonal variation for dark layered cards and recessed surfaces.
- **Surface Charcoal (`#1A1A1A`):** Elevated dark interactive cards and floating dialog backgrounds.
- **Ink Stone (`#5A5A5A`):** Secondary metadata, inactive links, and muted structural guidelines.
- **Ink Ivory (`#F7F5F0`):** Alabaster light canvas, evoking deckle-edge rag paper and Carrara marble.
- **Ink Beige (`#EBE2D6`):** Warm vellum for chips, pills, elevated containers, and language toggles.

### Functional, Overlay, & Glow Tones
- **Aura Gold Glow (`rgba(218, 175, 55, 0.25)`):** Ambient luminous bloom on focused inputs, hover states, and floating actions.
- **Hairline Stone (`rgba(90, 90, 90, 0.2)`):** Architectural grid dividers and inactive borders.
- **Hairline Gold (`rgba(218, 175, 55, 0.5)`):** Emphasized borders and active focus rings.
- **Error / Contraindication (`#8B1E1E`):** Dried crimson ink for warnings and form invalidation.
- **Success / Botanical (`#2E5A44`):** Gilded forest pine for completion markers and hygienic confirmations.

## Typography

### Typographic Treatment
Typography is treated as an architectural sculpture, utilizing the refined chiseled serifs of `EB Garamond`. The typographic hierarchy relies on extreme tracking variations rather than heavy font weights:

- **Expansive Tracking Rule:** All structural labels, eyebrow headers, navigation links, and display titles are set strictly in uppercase with wide letter tracking (`0.15em` to `0.4em`).
- **Body & Editorial Reading:** Body typography is typeset in sentence case with natural, breathable tracking (`0.01em` to `0.02em`) and relaxed leading to ensure sustained comfort on both dark and light canvases.
- **Italic Voice:** Poetic epigraphs, artist philosophies, and testimonials utilize natural italic serif variations with open vertical rhythm.
- **Text Selection:** Always tinted with the signature metallic hue: `::selection { background-color: #DAAF37; color: #000000; }`.

## Layout & Spacing

### Grid Architecture
The layout uses a 12-column responsive fluid grid pinned to precise maximum structural bounds:
- **Global Canvas Container:** `max-w-6xl` (1152px) for grand galleries, master indexes, and navigation bars.
- **Editorial Canvas Container:** `max-w-4xl` (896px) for narrative artist statements and studio philosophies.
- **Intimate Interaction Container:** `max-w-3xl` (768px) for private consultation bookings, intake documentation, and single-column accordions.

### Form Factors & Adaptability
- **Mobile (< 768px):** 4-column structure with `1rem` margins and gutters. Single-column stacks for forms and artist portraits; 2-column grids for gallery mosaics. Fixed background textures gracefully fall back to local scrolling to safeguard touch framerates.
- **Tablet (768px - 1024px):** 8-column layout with `1.5rem` margins and gutters. Two-column cards and balance-centered quotes.
- **Desktop (> 1024px):** Full 12-column system, `3rem` outer margins, `1.5rem` gutters. Balanced 3-column matrices (`grid-cols-3 gap-8`).

### Rhythm & Alternating Canvases
Sections alternate vertically between warm illuminated canvases (Ivory and translucent Carrara washes) and atmospheric darkrooms (Noir Ink Absolute) to establish cadence:
1. Hero: Warm Alabaster Marble
2. Philosophy: Serene Ink Ivory
3. Artists: Noir Ink Absolute
4. Gallery Mosaic: Warm Alabaster Marble
5. Protocol & Aftercare: Ink Ivory
6. Consultation Booking: Noir Ink Absolute
7. Colophon: Warm Alabaster Marble

Vertical section breathing space scales from `3.5rem` (56px) on mobile to `5rem` (80px) on desktop viewports.

## Elevation & Depth

### Atmospheric Depth Philosophy
The design avoids murky, diffuse black drop shadows. Depth is achieved through precise hairline enclosures, frosted translucency, and warm metallic luminance:

- **Surface Tiers (Dark Canvas):**
  - *Base:* Noir Ink (`#000000`).
  - *Tier 1 (Cards, Overlays):* Noir Deep (`#0A0A0A`) with a hairline border (`rgba(90, 90, 90, 0.2)`).
  - *Tier 2 (Modals, Floats):* Surface Charcoal (`#1A1A1A`) with an accent border (`rgba(218, 175, 55, 0.3)`).
- **Surface Tiers (Light Canvas):**
  - *Base:* Ink Ivory (`#F7F5F0`).
  - *Tier 1 (Cards):* Translucent alabaster wash (`rgba(255, 255, 255, 0.4)`) with a stone hairline boundary.
  - *Tier 2 (Sticky Headers):* `rgba(247, 245, 240, 0.9)` paired with `backdrop-blur-sm` and a 1px base rule `rgba(90, 90, 90, 0.15)`.

### Luminous Micro-Glow
Interactive focus and hover states invoke an intentional gold halo:
- **Button Hover Elevation:** `box-shadow: 0 0 20px rgba(218, 175, 55, 0.25)`.
- **Floating Controls (Scroll Sentinel):** `box-shadow: 0 0 24px rgba(218, 175, 55, 0.35)`.
- **Active Hairline Fields:** A directional gold glow along active input baseline borders.

## Shapes

### Corner Geometry
The design language enforces an architectural, crisp geometry (`roundedness: 0`). Elements favor sharp 90-degree corners, reflecting fine-line engraving plates, stone architectural tablets, and bespoke gold leaf framing:

- **Panels, Buttons, Inputs, & Cards:** Pure rectangular geometry (`0px` border radius).
- **Domain Accent Exceptions:**
  - *Artist Portfolios:* Circular avatar medallions (`rounded-full`) framed within a 1px imperial gold halo ring.
  - *Decorative Filigree Lozenges:* Symmetrical 45-degree tilted square diamonds (`rotate-45`) used as layout dividers.
  - *Floating Sentinel Action:* Circular disc (`rounded-full`) for tactile differentiation from the primary content plane.

## Components

### Buttons
All buttons maintain sharp corners, uppercase tracked text (`tracking-[0.25em]`), and smooth color transitions (300ms ease-out).
- **Primary CTA (Editorial Noir):**
  - Base: 1px border `border-ink-black`, transparent background, `text-ink-black`, `px-8 py-3`.
  - Hover: Inversion to solid `bg-ink-black` with `text-ink-ivory`.
- **Accent CTA (Atelier Gold):**
  - Base: 1px border `border-ink-gold`, `text-ink-gold`, transparent background, `px-8 py-3`.
  - Hover: Shifts to solid `bg-ink-gold` with `text-ink-black` and an ambient aura glow (`shadow-[0_0_20px_rgba(218,175,55,0.25)]`).
- **Ghost Action:**
  - Base: Uppercase tracking, `text-ink-stone`, no border.
  - Hover: Shifts cleanly to `text-ink-gold`.

### Form Inputs
- **Atelier Line Field:**
  - Minimal underline-only styling: transparent background, bottom hairline border (`border-b border-ink-stone/50 py-2.5 font-serif outline-none text-ink-ivory`).
  - Focus: Morph border to `border-ink-gold` with zero outline offset, complemented by a soft underside gold glow.
  - Labels: Floating static metadata set above each field in `label-eyebrow` typography with muted stone styling (`text-ink-stone`).

### Cards & Artwork Mosaics
- **Artwork Gallery Card:**
  - Square aspect ratio (`aspect-square`), sharp corners, 1px stone perimeter (`border border-ink-stone/20`), internal clipping.
  - Scrim: Vignette overlay gradient (`from-ink-black/80 via-transparent to-transparent`).
  - Hover: Smooth image zoom (`scale-105 duration-700 ease-out`) with the gold serif category and title elevating subtly from the lower edge.
- **Aftercare Protocol Card:**
  - Dual-tier container: Upper step photographic window accompanied by an ivory/gold metadata tag; lower body grounded in translucent white parchment (`bg-white/40`) with 24px internal padding and hairline borders.

### Lists & Accordions
- **Accordion FAQ Panel:**
  - Enclosed sharp box with internal dividers (`divide-y divide-ink-stone/20 border border-ink-stone/20`).
  - Trigger: Tracked serif question with an antique gold chevron rotating 180 degrees smoothly (`transition-transform duration-300`).
  - Content: Relaxed body typography wrapped in generous padding (`p-6`).

### Chips & Badges
- **Status & Style Badges:**
  - Fine-line rectangular tags with uppercase tracked typography (`text-[10px] tracking-[0.25em]`).
  - Base: `border border-ink-stone/30 text-ink-stone bg-transparent px-3 py-1`.
  - Active/Featured: `border-ink-gold text-ink-gold bg-ink-gold/10`.

### Checkboxes & Radio Controls
- **Neoclassical Custom Selectors:**
  - Sharp square boxes (16px by 16px) with 1px stone borders.
  - Checked: Solid fill in `bg-ink-gold` with a centered obsidian micro-diamond marker, replacing standard check icons.

### Domain-Specific Components
- **Subtle Gilded Divider:** Symmetrical accent featuring dual horizontal hairlines (`h-px w-16 bg-ink-gold/70`) framing a 45-degree rotated diamond lozenge (`w-1.5 h-1.5 rotate-45 bg-ink-gold`).
- **Monogram Cartouche:** Symmetrical botanical engraving mark scalable from header navigation (36px) to hero watermark scale (300px+).
- **Scroll Sentinel:** Floating circular button (`w-12 h-12 rounded-full border border-ink-gold bg-ink-ivory/90 backdrop-blur-sm text-ink-gold`) anchored at the bottom margin, fading into view past 480px scroll depth.